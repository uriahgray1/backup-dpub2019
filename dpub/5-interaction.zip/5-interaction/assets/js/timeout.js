$( document ).ready(function() {
    
    
setTimeout(function(){
    $('.title-1').addClass('active')
},1000);

setTimeout(function(){
    $('.title-2').addClass('active')
},2000);

setTimeout(function(){
    $('.title-3').addClass('active')
},3000);

setTimeout(function(){
    $('.image-container').addClass('active')
},4000);



















});