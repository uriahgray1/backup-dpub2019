$( document ).ready(function() {
    
 $( function() {
    $( ".drag-image").draggable();
  } );


















});