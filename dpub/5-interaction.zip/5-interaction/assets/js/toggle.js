$( document ).ready(function() {
    

$( ".title-1" ).click(function() {
  $( ".toggle-1" ).slideToggle( "slow" );
});

$( ".title-2" ).click(function() {
  $( ".toggle-2" ).slideToggle( "slow" );
});

$( ".title-3" ).click(function() {
  $( ".toggle-3" ).slideToggle( "slow" );
});



















});