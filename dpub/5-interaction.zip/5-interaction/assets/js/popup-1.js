$( document ).ready(function() {


// 25k popup    
$('.l-25k').click(function() {
  $('.p-25k').addClass('show');
});

$('.p-25k').click(function() {
  $('.p-25k').removeClass('show');
});

// 35k popup
$('.l-30k').click(function() {
  $('.p-30k').addClass('show');
});

$('.p-30k').click(function() {
  $('.p-30k').removeClass('show');
});

// 45k popup
$('.l-40k').click(function() {
  $('.p-40k').addClass('show');
});

$('.p-40k').click(function() {
  $('.p-40k').removeClass('show');
});



















});