$( document ).ready(function() {
    
$('.nav-contents').click(function() {
  $('.contents').addClass('left');
});

$('.close').click(function() {
  $('.contents').removeClass('left');
});




















});