$( document ).ready(function() {


// start shape popup
$('.l-1').click(function() {
  $('.s-1').addClass('show');
});
// end shape popup

// start shape popup
$('.l-2').click(function() {
  $('.s-2').addClass('show');
});
// end shape popup

// start shape popup
$('.l-3').click(function() {
  $('.s-3').addClass('show');
});
// end shape popup

// start shape popup
$('.l-4').click(function() {
  $('.s-4').addClass('show');
});
// end shape popup

// start shape popup
$('.l-5').click(function() {
  $('.s-5').addClass('show');
});
// end shape popup

// start shape popup
$('.l-6').click(function() {
  $('.s-6').addClass('show');
});
// end shape popup

// start shape popup
$('.l-7').click(function() {
  $('.s-7').addClass('show');
});
// end shape popup

// start shape popup
$('.l-8').click(function() {
  $('.s-8').addClass('show');
});
// end shape popup

// CLOSE ANY OPEN SHAPE
$('.shape').click(function() {
  $(this).removeClass('show');
});
// CLOSE ANY OPEN SHAPE



















});